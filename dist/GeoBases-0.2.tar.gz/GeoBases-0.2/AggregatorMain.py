#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
This module is an aggregator.
'''


from GeoBases.AggregatorModule import Aggregator
from GeoBases.GeoBaseModule  import GeoBase

import os.path as op
import argparse


def display_on_two_cols(a_list):
    '''
    Some formatting for help.
    '''

    for p in zip(a_list[::2], a_list[1::2]):
        print '\t%-15s\t%-15s' % p


def main():

    #
    # COMMAND LINE MANAGEMENT
    #
    parser = argparse.ArgumentParser(description='Aggregate csv files.')

    parser.epilog = 'Example: python %s file.csv -k 0 2 -f region_code month -v 4' % parser.prog

    parser.add_argument('file',
        help = '''Path to the file containing the data. If set to
                       "-", the script will read the standard input
                        instead.''',
        type = argparse.FileType('r'), 
        default = '-'
    )

    parser.add_argument('-d', '--delimiter',
        help = 'Column delimiter, default: ^',
        default = '^'
    )

    parser.add_argument('-o', '--output',
        help = 'Name of the output file, no option will print the results on stdout',
        default = None
    )

    parser.add_argument('-k', '--keys',
        help = 'Columns where we find the element of a key',
        required = True,
        nargs = '+'
    )

    parser.add_argument('-v', '--value',
        help = '''Column where we find the value for each key.
                        If not set, we will take 1 as default value (e.g. simple count)''',
        default = None
    )

    parser.add_argument('-f', '--fields',
        help = '''Information on aggregation. Must have the same number of
                        arguments as --keys, and possible values are given by
                        the GeoBase module and DateConverter modules (see normal output).
                        You may also provide "*" for "complete aggregation" and
                        "N" for "no aggregation".''',
        required = True,
        nargs = '+'
    )

    parser.add_argument('-r', '--reader',
        help = '''Optional date format, default %%Y%%m%%d. You may provide any
                        standard date format understood by Python datetime.''',
        default = '%Y%m%d'
    )

    parser.add_argument('-q', '--quiet',
        help = 'Quiet output, will not display anything except the results',
        action = 'store_true'
    )

    parser.add_argument('-m', '--monitor',
        help = '''Monitor loading of lines from file, every time
                    MONITOR lines is loaded. Option quiet must not be on,
                    default value set to 1000000.''',
        default = 1000000
    )

    parser.add_argument('-s', '--safe',
        help = '''If this option is on, the aggregation will
                      skip key conversion errors.
                      It may be a good idea to make a first run without it.''',
        action = 'store_true'
    )

    parser.add_argument('-b', '--base',
        help = '''Choose a different base, default is ori_por. Also available are
                        stations, stations_nls, airports, airports_csv, countries.''',
        default = 'ori_por'
    )
     
    args = vars(parser.parse_args())


    #
    # ARGUMENTS
    #

    # Lambda function for key creation when reading line
    lambda_key = lambda r: tuple(r[int(i)] for i in args['keys'])

    # If no value argument, we just count
    if args['value'] is None:
        lambda_value = lambda r : 1
    else:
        lambda_value = lambda r: float(r[int(args['value'])])


    no_agg = set(['n', 'N', 'None'])

    args['fields'] = tuple(None if f in no_agg else f 
                           for f in args['fields'])

    args['monitor'] = int(args['monitor'])


    #
    # AGGREGATION
    #
    if not args['quiet']:
        print '\nLoading GeoBase...'

    a = Aggregator(GeoBase(data=args['base'], verbose=False), 
                   fields=args['fields'],
                   safe_mode=args['safe'])

    if not args['quiet']:
        print '\nAvailable fields for aggregation from GeoBase:'
        display_on_two_cols(list(a._headers))

        print '\nAvailable fields for aggregation from DateConverter:'
        display_on_two_cols(list(a._dconv._date_formats))

    if not args['quiet']:
        print '\nParsing...'

    a.add_from_flike(args['file'],
                     args['delimiter'],
                     lambda_key,
                     lambda_value,
                     date_format=args['reader'],
                     verbose=not(args['quiet']),
                     monitor=args['monitor'])

    if not args['quiet']:
        print '\nDone.'

    a.aggregate(output='csv', out=args['output'])


if __name__ == '__main__':
    
    main()
    

