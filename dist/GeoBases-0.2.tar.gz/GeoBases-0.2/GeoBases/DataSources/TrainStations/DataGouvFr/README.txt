
Those 3 files have been [legally :)] downloaded from data.gouv.fr.
They have not been changed, except for delimiters (; to ^ for fields and , to . for decimal).

	http://www.data.gouv.fr/donnees/view/Liste-des-gares-de-voyageurs-du-RFN-avec-coordonn%C3%A9es-30383099
	http://www.data.gouv.fr/donnees/view/Gares-ferroviaires-de-tous-types%2C-exploit%C3%A9es-ou-non-30383132
	http://www.data.gouv.fr/donnees/view/Passages-%C3%A0-niveau-30383135