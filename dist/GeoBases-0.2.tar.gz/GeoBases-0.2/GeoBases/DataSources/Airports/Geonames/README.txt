This script extracts airports data from the Geonames tables.
It uses airports.csv to match airport to their cities, and list_countries.csv to match
airports to their country names.

As there are less airports in Geonames than airports.csv, the final file is smaller than airports.csv.
In the last version, cities have been removed (like Paris - All airports, PAR).
