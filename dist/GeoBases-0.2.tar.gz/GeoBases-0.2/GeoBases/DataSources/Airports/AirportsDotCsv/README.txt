
'airports.csv' is deprecated.

Use instead the the other file 'ORI_Simple_Airports_Database_Table.csv' from
http://mediawiki.orinet.nce.amadeus.net/index.php/Airport_ORI
