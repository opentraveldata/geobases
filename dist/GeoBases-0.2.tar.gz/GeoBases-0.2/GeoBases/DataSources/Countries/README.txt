This a list of country codes.
