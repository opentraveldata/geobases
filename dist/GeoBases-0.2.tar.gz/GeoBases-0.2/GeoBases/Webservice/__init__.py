#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
This is the GeoBase module.
'''
